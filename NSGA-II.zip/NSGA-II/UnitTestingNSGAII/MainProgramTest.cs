﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSGA_II;

namespace UnitTestingNSGAII
{
    [TestClass]
    public class MainProgramTest
    {
        [TestMethod]
        public void TestMethod1()
        {
        }
    }
}
