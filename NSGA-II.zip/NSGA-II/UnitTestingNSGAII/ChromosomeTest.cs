﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using NSGA_II;
using System;

namespace UnitTestingNSGAII
{
    [TestClass]
    public class ChromosomeTest
    {
        [TestMethod]
        public void TestMinGeneFirstInterval()
        {
            double[] minGs = { 1, 2, 3 };
            double[] maxGs = { 5, 6, 7 };
            Chromosome c = new Chromosome(3, minGs, maxGs);
            Assert.IsTrue(minGs[0] <= c.Genes[0]);
        }

        [TestMethod]
        public void TestMinGeneSecondInterval()
        {
            double[] minGs = { 1, 2, 3 };
            double[] maxGs = { 5, 6, 7 };
            Chromosome c = new Chromosome(3, minGs, maxGs);
            Assert.IsTrue(minGs[1] <= c.Genes[1]);
        }

        [TestMethod]
        public void TestMinGeneThirdInterval()
        {
            double[] minGs = { 1, 2, 3 };
            double[] maxGs = { 5, 6, 7 };
            Chromosome c = new Chromosome(3, minGs, maxGs);
            Assert.IsTrue(minGs[2] <= c.Genes[2]);
        }

        [TestMethod]
        public void TestMaxGeneInterval()
        {
            double[] minGs = { 1, 2, 3 };
            double[] maxGs = { 5, 6, 7 };
            Chromosome c = new Chromosome(3, minGs, maxGs);

            Random r = new Random();
            int indexRandom = r.Next(minGs.Length);
            Console.WriteLine(indexRandom);

            Assert.IsTrue(minGs[indexRandom] <= c.Genes[indexRandom]);
        }

        [TestMethod]
        public void TestNoGenes()
        {
            double[] minGs = { 1, 2, 3 };
            double[] maxGs = { 5, 6, 7 };
            Chromosome c = new Chromosome(minGs.Length, minGs, maxGs);
            Assert.AreEqual(minGs.Length, c.Genes.Length);
        }

        [TestMethod]
        public void TestCopyGenesIndivid()
        {
            double[] minGs = { 1, 2, 3 };
            double[] maxGs = { 5, 6, 7 };
            Chromosome c = new Chromosome(minGs.Length, minGs, maxGs);
            Chromosome copy = new Chromosome(c.Genes.Length, c.Genes, c.MinValues, c.MaxValues);
            Random r = new Random();
            int indexRandom = r.Next(minGs.Length);
            Console.WriteLine(indexRandom);
            Assert.AreEqual(c.Genes[indexRandom], copy.Genes[indexRandom]);
        }
    }
}
